package com.example2;
public class sum{
	public static void main(String[] args){
		int a=10;
		int b=20;
		int sum=a+b;
		System.out.println("Sum of 10 and 20 is "+sum);
	}
}
