package com.example;
public class print{
public static void main(String [] args)
{
System.out.println("Namaskara");
}
}
